package com.honey.jsService;


public class Gen {

	
	public boolean returnTrue()
	{
		return true;
	}

	
}
