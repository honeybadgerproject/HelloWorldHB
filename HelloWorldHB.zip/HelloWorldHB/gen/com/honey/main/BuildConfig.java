/** Automatically generated file. DO NOT MODIFY */
package com.honey.main;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}